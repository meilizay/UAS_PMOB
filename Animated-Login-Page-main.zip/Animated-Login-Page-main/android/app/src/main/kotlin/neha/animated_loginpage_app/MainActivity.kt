package neha.animated_loginpage_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
